<?php
return [
    '360gh'=>[
        // 数据库类型
        'type'        => 'mysql',
        // 服务器地址
        'hostname'    => '113.105.191.213',
        // 数据库名
        'database'    => '360gh',
        // 数据库用户名
        'username'    => 'root',
        // 数据库密码
        'password'    => 'Tpadmin2018',
        // 数据库编码默认采用utf8
        'charset'     => 'utf8',
        // 数据库表前缀
        'prefix'      => '33hao_',
    ]
];