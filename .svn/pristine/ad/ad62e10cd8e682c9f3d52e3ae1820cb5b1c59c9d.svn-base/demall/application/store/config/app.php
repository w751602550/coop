<?php
/**
 *USER:binbin
 *DATE:2019/5/20 0020
 *TIME:下午 15:35
 */
return [
    'default_return_type'=>'html',
    'default_filter'=>'trim,htmlspecialchars',
    'gh_image'=>'http://www.360gh.com/data/upload/shop/store/goods/',
];