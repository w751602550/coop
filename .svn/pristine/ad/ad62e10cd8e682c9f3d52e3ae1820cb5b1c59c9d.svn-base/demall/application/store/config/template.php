<?php
/**
 *USER:binbin
 *DATE:2019/5/21 0021
 *TIME:下午 14:15
 */
return [
    'layout_on' => true,
    'layout_name' => 'layouts/layout',
];