<?php


namespace app\store\controller;


class Order extends Base
{
    public function index(){
        return '';
    }

    public function all_list(){
        return '';
    }
}