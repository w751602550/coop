<?php


namespace app\store\model;


class MemberGoods extends Store
{
    public $pk = 'member_goods_id';

    public function goods()
    {
        return $this->hasOne('goods', 'goods_id', 'goods_id');
    }

    public function getPage($condition=[])
    {
        return $this->with('goods')->where($condition)->paginate($this->psize);
    }

    public function getMemberGoodsId($member_id)
    {
        return $this->where('member_id',$member_id)->column('goods_id');
    }

    public function add($goods, $member_id)
    {
        $memberGoodsList = $this->getMemberGoodsId($member_id);
        $data = [];
        if (is_array($goods)) {
            foreach ($goods as $key => $val) {
                if (in_array($val, $memberGoodsList))
                    continue;
                $supper_goods = (new Goods)->detail($val);
                $data[$key]['store_id'] = $this->store_id;
                $data[$key]['goods_id'] = $val;
                $data[$key]['member_id'] = $member_id;
                $data[$key]['price'] = $supper_goods['goods_price'];
            }
            return $this->saveAll($data);
        }
        if (in_array($goods, $memberGoodsList)) {
            $this->error = '该商品己是合约商品';
            return false;
        }
        $supper_goods = (new Goods)->detail($goods);
        $data['store_id'] = $this->store_id;
        $data['goods_id'] = $goods;
        $data['member_id'] = $member_id;
        $data['price'] = $supper_goods['goods_price'];
        return $this->save($data);
    }

    public function setDelete($condition){
        return $this->where($condition)->delete();
    }
}