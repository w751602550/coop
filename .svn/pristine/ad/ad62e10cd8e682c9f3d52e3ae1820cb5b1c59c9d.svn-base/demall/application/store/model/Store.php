<?php


namespace app\store\model;


class Store extends BaseModel
{
    protected function base($query){
        $query->where('store_id',$this->store_id);
    }
}