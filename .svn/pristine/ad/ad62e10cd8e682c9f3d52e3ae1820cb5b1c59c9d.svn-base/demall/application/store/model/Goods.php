<?php


namespace app\store\model;

use app\store\model\shopgh\GoodsImages as ghGoodsImage;
use think\Db;

class Goods extends Store
{
    protected $pk = 'goods_id';

    public function getStatusAttr($value)
    {
        $status = [
            '0' => '下架',
            '1' => '上架',
            '10' => '违规'
        ];
        return ['text' => $status[$value], 'value' => $value];
    }

    public function getPage()
    {
        $field = ['goods_id', 'goods_name', 'goods_price', 'goods_marketprice', 'goods_image', 'goods_edittime', 'category_name', 'status', 'update_time'];
        return $this->where('store_id', $this->store_id)->field($field)->paginate($this->psize);
    }

    public function import($data)
    {
        $data['gh_goods_id'] = $data['goods_id'];
        unset($data['goods_id']);
        $data['gh_goods_commonid'] = $data['goods_commonid'];
        $data['store_id'] = $this->store['store']['store_id'];
        $data['goods_image'] = $this->gh_image . $data['goods_image'];
        $data['status'] = $data['goods_state']['value'];
        $goodsImages = (new ghGoodsImage)->getList($data['gh_goods_commonid']);
        Db::startTrans();
        try {
            $this->allowField(true)->save($data);
            (new GoodsImages)->addByGh($goodsImages, $this->goods_id);
            Db::commit();
        } catch (\Exception $e) {
            Db::rollback();
            $this->error = $e->getMessage();
            return false;
        }
        return true;
    }

    public function getGhGoodsId()
    {
        return $this->column('gh_goods_id');
    }


    public function checkExist($condition)
    {
        return $this->find($condition);
    }

    public function detail($key)
    {
        return $this->get($key);
    }

    public function setDelete($goods_id)
    {
        Db::startTrans();
        try {
            $this->where(['goods_id' => $goods_id, 'store_id' => $this->store_id])->delete();
            (new GoodsImages)->setDelete(['goods_id' => $goods_id, 'store_id' => $this->store_id]);
            Db::commit();
        } catch (\Exception $e) {
            Db::rollback();
            $this->error = $e->getMessage();
            return false;
        }
        return true;
    }
}