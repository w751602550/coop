<?php


namespace app\store\model\shopgh;

use app\store\model\BaseModel;

class ShopModel extends BaseModel
{
    protected $connection = '360gh';
}