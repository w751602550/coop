<?php

namespace app\home\controller;

use app\home\model\Member as memberModel;
use think\facade\Session;

class Member extends Base
{

    public function index()
    {
        return $this->fetch('index');
    }

    public function login()
    {
        if ($this->ajax) {
            $post = postData('member');
            $model=new memberModel();
            if($model->checkLogin($post))
                return ajaxSuccess(getchina('loginSuccess'));
            return ajaxError(getchina('loginError').':'.$model->getError());
        }
        return $this->fetch('login');
    }

    public function logout(){
        Session::delete(MEMBER);
        $this->redirect('member/login');
    }


}
