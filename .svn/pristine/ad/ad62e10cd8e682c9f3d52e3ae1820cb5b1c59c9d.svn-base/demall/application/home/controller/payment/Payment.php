<?php


namespace app\home\controller\payment;


use app\home\controller\Base;

class Payment extends Base
{

}