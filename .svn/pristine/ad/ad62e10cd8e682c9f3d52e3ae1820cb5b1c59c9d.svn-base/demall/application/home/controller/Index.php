<?php

namespace app\home\controller;


class Index extends Base
{
   public function index(){
     return redirect('member/index');
   }
}
