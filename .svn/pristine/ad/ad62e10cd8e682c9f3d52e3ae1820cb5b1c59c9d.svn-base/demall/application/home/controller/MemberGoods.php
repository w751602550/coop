<?php


namespace app\home\controller;

use app\home\model\MemberGoods as memberGoodsModel;
use app\home\model\Goods;
class MemberGoods extends Base
{
    public function index()
    {
        $list = (new memberGoodsModel)->getPage();
        return $this->fetch('index', compact('list'));
    }

    public function delete($member_goods_id)
    {
        if ($this->ajax) {
            $goods = (new memberGoodsModel)->get($member_goods_id);
            if (!$goods) {
                return ajaxError('合约商品不存在');
            }
            if ($goods->delete())
                return ajaxSuccess('删除成功', url('index'));
            return ajaxError('删除失败');
        }
    }

    public function add($member_goods_id){
        if ($this->ajax) {
            $goods = (new Goods)->get($member_goods_id);
            if (!$goods || $goods['status'] != 1) {
                return ajaxError('商品不存在或己下架');
            }
            if ((new memberGoodsModel)->add($goods))
                return ajaxSuccess('加入成功', url('goods/index'));
            return ajaxError('删除失败');
        }
    }

}