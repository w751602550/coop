<?php


namespace app\home\controller\member;

use app\home\controller\Base;

class Invoice extends Base
{
    public function index()
    {
        return $this->fetch('index');
    }
    public function add(){
        return $this->fetch('add');
    }
}