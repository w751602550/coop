<?php


namespace app\home\controller;


use app\home\model\OrderGoods;
use think\facade\Request;
use app\home\model\MemberGoods;
use app\home\model\Order as orderModel;

class Order extends Base
{
    protected $geterror;

    public function index()
    {
        $list = (new orderModel)->getPage();
        return $this->fetch('index', compact('list'));
    }

    public function confirm($order_id)
    {
        $order = orderModel::detail($order_id);
        if ($this->ajax) {
            if (!$order || $order['status']['value'] != 10)
                return ajaxError('订单状态有误');
            $post = postData('order');
            if ($post['payment_type'] == 'online') {
                $post['status'] = 15;
            } else {
                $post['confirm_time'] = time();
                $post['status'] = 20;
            }
            $post['payment_sn'] = $order->payNo();
            if ($order->edit($post, $order_id))
                return ajaxSuccess('确认成功', url('index'));
            return ajaxError('确认失败');
        }
        if (!$order || $order['status']['value'] != 10)
            $this->error('订单状态有误');
        return $this->fetch('confirm', compact('order'));
    }

    public function pay($order_id)
    {
        $model = new orderModel();
        $order = $model->get($order_id);
        if ($this->post) {
            if (!$order || $order['status']['value'] != 15)
                return ajaxError('订单状态有误');
            return $this->payUnion($order);
        }
        if (!$order || $order['status']['value'] != 15) {
            $this->error('订单状态有误');
        }
        return $this->fetch('pay', compact('order'));
    }

    private function payUnion($order)
    {
        $data = [];
        $data['MerId'] = '541171910140001';
        $data['MerOrderNo'] = $order['order_sn'];
        $data['OrderAmt'] = $order['total_price'] * 100;
        $data['TranDate'] = date('Ymd', time());
        $data['TranTime'] = date('his', time());
        $data['BusiType'] = '0001';
        $data['Version'] = '20140728';
        $data['MerPageUrl'] = 'http://demall.com/home/show_message/index.html';
        $data['MerBgUrl'] = 'http://demall.com/home/show_message/index.html';
        //  $data['trans_P1'] = $payment_sn['pay_sn'];
        $data['MerResv'] = $order['payment_sn'];
        $data['AcqCode'] = '000000000000014';
        echo (new payment\unionpay\Unionpay())->bulidSign($data);
        exit();
    }

    public function import($error = '')
    {
        return $this->fetch('import', compact('error'));
    }

    public function importFile()
    {
        $error = [];
        if ($this->post) {
            if (!$data = $this->getExcel()) {
                $error[] = $this->geterror;
            } else {
                $error = $this->geterror;
                if (!$error) {
                    $orderModel = new orderModel();
                    if ($orderModel->buildOrder($data)) {
                        return redirect('order/index');
                    }
                }
            }
        }
        return $this->import($error);
    }

    public function showError($error)
    {
        return $this->fetch('import', compact('error'));
    }

    public function getExcel()
    {
        if (!$file = Request::file('iFile')) {
            $this->geterror = '文件不存在';
            return false;
        }
        $uploadPath = WEB_PATH . 'upload' . DS . 'file';
        $info = $file->validate(['size' => 10 * 1024 * 1024, 'ext' => 'xls,xlsx'])->move($uploadPath);
        if (!$info) {
            $this->geterror = '文件过大或格式不正确，上传失败';
            return false;
        }
        $ext = $info->getExtension();
        $filePath = $uploadPath . DS . $info->getSaveName();
        if ($ext == 'xlsx') {
            $reader = \PHPExcel_IOFactory::createReader('Excel2007');
        } else {
            $reader = \PHPExcel_IOFactory::createReader('Excel5');
        }
        $excel = $reader->load($filePath, $encode = 'utf-8');
        $sheet = $excel->getSheet(0)->toArray();
        if (count($sheet) < 2) {
            $this->geterror = '文件中没有数据';
            return false;
        }
        unset($sheet[0]);
        $data = [];
        $error = [];
        foreach ($sheet as $key => $val) {
            $member_goods = $this->checkGoodsPrice($val[8]);
            $line = ++$key;
            if (!$member_goods) {
                $error[] = "第" . $line . "行的商品($val[9])不存在或非合约商品";
                continue;
            }
            if ($member_goods['price'] != $val[12]) {
                $error[] = "第" . $line . "行的商品($val[9])价格与合约商品价格不一致";
                continue;
            }
            if (round($val[10]) < 1) {
                $error[] = "第" . $line . "行的商品($val[9])数量不正确";
                continue;
            }
            $name = trim($val[0]);
            if (!isset($data[$name]))
                $data[$name] = $val;
            if (isset($data[$name]['goods'][$val[8]])) {
                $data[$name]['goods'][$val[8]]['goods_number'] += round($val[10]);
            } else {
                $data[$name]['goods'][$val[8]] = [
                    'goods_id' => $val[8],
                    'goods_name' => $val[9],
                    'goods_number' => round($val[10]),
                    'remark' => $val[11],
                    'goods_image' => $member_goods['goods_image'],
                    'price' => round($val[12], 2),
                ];
            }
        }
        $this->geterror = $error;
        return $data;
    }

    public function checkGoodsPrice($member_goods_id)
    {
        return MemberGoods::detail($member_goods_id);
    }

}