<?php


namespace app\home\controller;
use app\home\model\Goods as goodsModel;
use app\home\model\MemberGoods;

class Goods extends Base
{
    public function index(){
        $list=(new goodsModel)->getpage();
        $goodsIdList=(new MemberGoods)->getGoodsIdList();
        return $this->fetch('index',compact('list','goodsIdList'));
    }
}