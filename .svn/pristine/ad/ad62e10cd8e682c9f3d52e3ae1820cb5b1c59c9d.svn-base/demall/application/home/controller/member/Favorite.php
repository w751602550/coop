<?php


namespace app\home\controller\member;


use app\home\controller\Base;

class Favorite extends Base
{

}