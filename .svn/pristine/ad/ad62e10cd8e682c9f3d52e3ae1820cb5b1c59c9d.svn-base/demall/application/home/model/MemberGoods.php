<?php


namespace app\home\model;


class MemberGoods extends BaseModel
{
    protected $pk = 'member_goods_id';

    protected function base($query)
    {
        return $query->where('member_id', $this->member_id);
    }

    public function goods()
    {
        return $this->hasOne('goods', 'goods_id', 'goods_id')->bind(['goods_image' => 'goods_image', 'goods_name' => 'goods_name', 'category_name' => 'category_name']);
    }

    public function add($goods)
    {
        $membergoods = [];
        $membergoods['store_id'] = $goods['store_id'];
        $membergoods['goods_id'] = $goods['goods_id'];
        $membergoods['member_id'] = $this->member_id;
        $membergoods['price'] = $goods['goods_price'];
        return $this->allowField(true)->save($membergoods);
    }

    public function getpage($condition = [])
    {
        $condition['member_id'] = $this->member_id;
        return $this->with('goods')->where($condition)->order('update_time desc')->paginate($this->psize);
    }

    public function getGoodsIdList()
    {
        return $this->column('goods_id');
    }

    public static function detail($member_goods_id)
    {
        return self::with('goods')->get($member_goods_id);
    }


}