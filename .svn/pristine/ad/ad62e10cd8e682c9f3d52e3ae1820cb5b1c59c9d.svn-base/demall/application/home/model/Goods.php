<?php


namespace app\home\model;


use think\facade\Request;

class Goods extends BaseModel
{
    protected $pk = 'goods_id';

    public function getPage()
    {
        $field = ['goods_id', 'goods_name', 'goods_price', 'goods_image', 'category_name'];
        $condition['status'] = 1;
        return $this->where($condition)->field($field)->paginate($this->psize, 'false', ['query' => Request::instance()->request()]);
    }
}