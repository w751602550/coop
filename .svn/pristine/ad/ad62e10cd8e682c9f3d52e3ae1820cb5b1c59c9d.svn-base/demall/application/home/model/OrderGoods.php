<?php


namespace app\home\model;


class OrderGoods extends BaseModel
{
    protected $pk = 'order_goods_id';

    public function addAll($data){
        return $this->allowField(true)->saveAll($data);
    }
}