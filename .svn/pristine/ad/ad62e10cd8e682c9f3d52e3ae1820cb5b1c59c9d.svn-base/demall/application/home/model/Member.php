<?php


namespace app\home\model;


use think\facade\Session;

class Member extends BaseModel
{
    public function setPasswordAttr($value)
    {
        return pwd_hash($value);
    }

    public function detail($condition = [])
    {
        return $this->where($condition)->find();
    }

    public function checkLogin($data)
    {
        $member = $this->detail(['member_name|phone' => $data['member_name']]);
        if (!$member) {
            $this->error = '用户名不存在';
            return false;
        }
        if ($member['password'] != pwd_hash($data['password'])) {
            $this->error = '密码错误,请重新输入';
            return false;
        }
        if ($member['status'] != 1) {
            $this->error = '当前状态己被锁定，请联系管理员';
            return false;
        }
        $member->memberState();
        return true;
    }

    public function memberState()
    {
        $session = [
            'member' => [
                'member_id' => $this->member_id,
                'member_name' => $this->member_name,
            ],
            'is_login' => 'true'
        ];
        Session::set(MEMBER, $session);
    }
}