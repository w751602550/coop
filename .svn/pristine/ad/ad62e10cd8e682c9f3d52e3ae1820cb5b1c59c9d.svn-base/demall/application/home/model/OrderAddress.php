<?php


namespace app\home\model;


class OrderAddress extends BaseModel
{
    protected $pk = 'address_id';
}