<?php

use think\facade\Request;

!defined('MEMBER') && define('MEMBER', 'bin_member');
function pwd_hash($pwd)
{
    return md5(md5($pwd . "_binbin"));
}


function toUnderScore($str)
{
    $dstr = preg_replace_callback('/([A-Z]+)/', function ($matchs) {
        return '_' . strtolower($matchs[0]);
    }, $str);
    return trim(preg_replace('/_{2,}/', '_', $dstr), '_');
}

function binJson($code = '', $msg = '', $url = '', $result = [])
{
    return compact('code', 'msg', 'url', 'result');
}

function ajaxSuccess($msg = '', $url = '', $data = [])
{
    return binJson(1, $msg, $url, $data);
}

function ajaxError($msg = '', $url = '', $data = [])
{
    return binJson(0, $msg, $url, $data);
}

function postData($key)
{
    return input($key . '/a');
}

function getData($key)
{
    return input($key . '/a');
}


function base_url()
{
    $request = Request::instance();
    $subDir = str_replace('\\', '/', dirname($request->server('PHP_SELF')));
    return $request->scheme() . '://' . $request->host() . $subDir . ($subDir === '/' ? '' : '/');
}

function getchina($key = '')
{
    $zh = [
        '' => '',
        'captchaError' => '验证码错误',
        'noMemberName' => '用户名不存在，请重新输入',
        'passwordError' => '密码错误,请重新输入',
        'loginSuccess' => '登录成功',
        'loginError' => '登录失败'
    ];
    return isset($zh[$key]) ? $zh[$key] : '';
}