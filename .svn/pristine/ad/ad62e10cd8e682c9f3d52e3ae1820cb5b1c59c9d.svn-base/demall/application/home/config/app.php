<?php

return [
//默认错误跳转对应的模板文件
    'dispatch_error_tmpl' => 'layout/dispatch_jump',
    //默认成功跳转对应的模板文件
    'dispatch_success_tmpl' => 'layout/dispatch_jump',
];