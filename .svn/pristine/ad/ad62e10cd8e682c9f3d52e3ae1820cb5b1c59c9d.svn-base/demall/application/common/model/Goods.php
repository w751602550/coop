<?php


namespace app\common\model;


class Goods extends BaseModel
{

}