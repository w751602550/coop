<?php


namespace app\common\model;


class BaseModel extends Base
{

}