<?php
$style_data = array(
    'default' => array('truename' => '我的默认小店'),
    /*'style1' => array('truename' => 'AppleStore'),
    'style2' => array('truename' => '中式水墨典雅'),
    'style3' => array('truename' => '蓝粉卡通玩具'),
    'style4' => array('truename' => '木纹爱心宠物'),
    'style5' => array('truename' => '纯色简约线条')*/
);
?>